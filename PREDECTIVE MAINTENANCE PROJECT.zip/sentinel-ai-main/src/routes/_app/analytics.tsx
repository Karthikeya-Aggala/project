import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { INDUSTRIES, MACHINES } from "@/lib/industries";

export const Route = createFileRoute("/_app/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — PREDICT.AI" },
      { name: "description", content: "Sensor trends, failure distribution, and uptime analytics." },
    ],
  }),
  component: Analytics,
});

const failureDist = [
  { name: "Bearing wear", value: 38 },
  { name: "Electrical", value: 22 },
  { name: "Lubrication", value: 18 },
  { name: "Thermal", value: 14 },
  { name: "Other", value: 8 },
];
const COLORS = ["oklch(0.78 0.17 210)", "oklch(0.78 0.17 60)", "oklch(0.72 0.18 155)", "oklch(0.70 0.20 320)", "oklch(0.65 0.24 25)"];

function Analytics() {
  const industryData = INDUSTRIES.map((i) => ({ name: i.name.split(" ")[0], health: i.health }));
  const uptime = MACHINES.map((m) => ({ name: m.name.split(" ")[0], uptime: 80 + Math.round(Math.random() * 19) }));

  return (
    <div className="space-y-6 p-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Analytics</h1>
        <p className="text-sm text-muted-foreground">Predictive insights across your fleet.</p>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="border-border/60 bg-card/60">
          <CardHeader><CardTitle className="font-display text-base">Industry Health</CardTitle></CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={industryData}>
                <CartesianGrid stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "oklch(0.68 0.02 230)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "oklch(0.68 0.02 230)", fontSize: 11 }} axisLine={false} tickLine={false} domain={[60, 100]} />
                <Tooltip contentStyle={{ background: "oklch(0.20 0.03 240)", border: "1px solid oklch(0.30 0.03 235 / 70%)", borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="health" fill="oklch(0.78 0.17 210)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/60">
          <CardHeader><CardTitle className="font-display text-base">Failure distribution</CardTitle></CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={failureDist} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100} stroke="oklch(0.16 0.025 240)">
                  {failureDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Legend wrapperStyle={{ fontSize: 11, color: "oklch(0.68 0.02 230)" }} />
                <Tooltip contentStyle={{ background: "oklch(0.20 0.03 240)", border: "1px solid oklch(0.30 0.03 235 / 70%)", borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/60 lg:col-span-2">
          <CardHeader><CardTitle className="font-display text-base">Machine uptime</CardTitle></CardHeader>
          <CardContent className="h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={uptime}>
                <CartesianGrid stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "oklch(0.68 0.02 230)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "oklch(0.68 0.02 230)", fontSize: 11 }} axisLine={false} tickLine={false} domain={[60, 100]} />
                <Tooltip contentStyle={{ background: "oklch(0.20 0.03 240)", border: "1px solid oklch(0.30 0.03 235 / 70%)", borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="uptime" fill="oklch(0.78 0.17 60)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
