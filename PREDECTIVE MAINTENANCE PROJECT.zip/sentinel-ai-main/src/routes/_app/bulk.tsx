import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload, Download, Loader2 } from "lucide-react";
import { predictMachine } from "@/server/predict.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/bulk")({
  head: () => ({
    meta: [
      { title: "Bulk CSV Prediction — PREDICT.AI" },
      { name: "description", content: "Upload sensor CSV for batch predictions and download the report." },
    ],
  }),
  component: BulkPage,
});

const COLS = ["temperature", "vibration", "voltage", "current", "rpm", "pressure", "oil_level", "load_capacity"] as const;

function BulkPage() {
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [rows, setRows] = useState<Array<Record<string, string | number>>>([]);
  const predict = useServerFn(predictMachine);

  async function process() {
    if (!file) return;
    setBusy(true);
    try {
      const text = await file.text();
      const lines = text.split(/\r?\n/).filter(Boolean);
      const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
      const out: Array<Record<string, string | number>> = [];
      for (let i = 1; i < lines.length && i <= 200; i++) {
        const cells = lines[i].split(",");
        const sensors: Record<string, number> = {};
        for (const c of COLS) {
          const idx = header.indexOf(c);
          sensors[c] = idx >= 0 ? Number(cells[idx]) : 0;
        }
        const r = await predict({ data: { machineId: `row-${i}`, sensors: sensors as any } });
        out.push({ row: i, ...sensors, prediction: r.label, confidence: r.confidence, risk: r.risk, rul_hours: r.rulHours });
      }
      setRows(out);
      toast.success(`Processed ${out.length} rows`);
    } catch (e) {
      toast.error("Failed to parse CSV. Expected columns: " + COLS.join(", "));
    } finally {
      setBusy(false);
    }
  }

  function download() {
    if (!rows.length) return;
    const headers = Object.keys(rows[0]);
    const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => r[h]).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "predictions.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6 p-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Bulk CSV Prediction</h1>
        <p className="text-sm text-muted-foreground">Required columns: <code>{COLS.join(", ")}</code>. Up to 200 rows per upload.</p>
      </header>

      <Card className="border-border/60 bg-card/60">
        <CardHeader><CardTitle className="font-display text-base">Upload</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Input type="file" accept=".csv,text/csv" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          <div className="flex gap-2">
            <Button onClick={process} disabled={!file || busy} className="bg-gradient-to-r from-primary to-[oklch(0.85_0.18_200)] text-primary-foreground">
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
              Run predictions
            </Button>
            <Button onClick={download} variant="outline" disabled={!rows.length}>
              <Download className="mr-2 h-4 w-4" /> Download report
            </Button>
          </div>
        </CardContent>
      </Card>

      {rows.length > 0 && (
        <Card className="border-border/60 bg-card/60">
          <CardHeader><CardTitle className="font-display text-base">Preview ({rows.length} rows)</CardTitle></CardHeader>
          <CardContent className="overflow-auto">
            <table className="min-w-full text-xs">
              <thead className="text-muted-foreground">
                <tr>{Object.keys(rows[0]).map((h) => <th key={h} className="px-2 py-1 text-left uppercase tracking-wider">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.slice(0, 50).map((r, i) => (
                  <tr key={i} className="border-t border-border/40">
                    {Object.keys(rows[0]).map((h) => (
                      <td key={h} className={`px-2 py-1 tabular-nums ${h === "prediction" ? (r[h] === "Failure" ? "text-destructive" : "text-success") : ""}`}>
                        {String(r[h])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length > 50 && <div className="mt-2 text-xs text-muted-foreground">Showing first 50 rows. Download for full report.</div>}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
