import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { StatusBadge } from "@/components/StatusBadge";
import { MACHINES } from "@/lib/industries";
import { ArrowRight, Cpu } from "lucide-react";

export const Route = createFileRoute("/_app/machines/")({
  head: () => ({
    meta: [
      { title: "Machines — PREDICT.AI" },
      { name: "description", content: "All monitored machines with live health and RUL." },
    ],
  }),
  component: MachinesIndex,
});

function MachinesIndex() {
  return (
    <div className="space-y-6 p-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Machines</h1>
        <p className="text-sm text-muted-foreground">All onboarded assets across industries.</p>
      </header>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {MACHINES.map((m) => (
          <Link key={m.id} to="/machines/$machineId" params={{ machineId: m.id }} className="group">
            <Card className="overflow-hidden border-border/60 bg-card/60 transition group-hover:-translate-y-1 group-hover:border-primary/40 group-hover:shadow-glow">
              <div className="relative h-40 overflow-hidden">
                <img src={m.image} alt={m.name} loading="lazy" width={1024} height={768} className="h-full w-full object-cover transition duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                <div className="absolute right-3 top-3"><StatusBadge status={m.status} /></div>
              </div>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Cpu className="h-4 w-4 text-primary" />
                  <span className="font-display text-base font-semibold">{m.name}</span>
                </div>
                <p className="mt-2 text-xs text-muted-foreground line-clamp-2">{m.usage}</p>
                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">RUL {m.rulHours}h • {m.health}%</span>
                  <span className="inline-flex items-center text-primary">Open <ArrowRight className="ml-1 h-3 w-3" /></span>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
