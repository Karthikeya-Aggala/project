import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { INDUSTRIES, MACHINES } from "@/lib/industries";
import { Activity, AlertTriangle, Cpu, Factory, ArrowRight, Bot, BarChart3 } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import heroImg from "@/assets/hero-industrial.jpg";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({
    meta: [
      { title: "Control Center — PREDICT.AI" },
      { name: "description", content: "Real-time KPIs, machine status, and AI insights across your industrial fleet." },
    ],
  }),
  component: Dashboard,
});

const trend = Array.from({ length: 24 }, (_, i) => ({
  t: `${i}:00`,
  health: 80 + Math.round(10 * Math.sin(i / 3) + (Math.random() * 4 - 2)),
  failures: Math.max(0, Math.round(2 + Math.sin(i / 4) * 1.5 + (Math.random() * 1.5 - 0.75))),
}));

function Kpi({ icon: Icon, label, value, delta, tone = "primary" }: { icon: any; label: string; value: string; delta?: string; tone?: "primary" | "accent" | "success" | "warning" }) {
  const toneCls = {
    primary: "from-primary/20 to-primary/0 text-primary",
    accent: "from-accent/20 to-accent/0 text-accent",
    success: "from-success/20 to-success/0 text-success",
    warning: "from-warning/20 to-warning/0 text-warning",
  }[tone];
  return (
    <Card className="relative overflow-hidden border-border/60 bg-card/60 transition hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-glow">
      <div className={`pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b ${toneCls}`} />
      <CardContent className="relative p-5">
        <div className="flex items-center justify-between">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
          <Icon className="h-4 w-4 text-muted-foreground" />
        </div>
        <div className="mt-3 font-display text-3xl font-bold tracking-tight">{value}</div>
        {delta && <div className="mt-1 text-xs text-muted-foreground">{delta}</div>}
      </CardContent>
    </Card>
  );
}

function Dashboard() {
  const totalMachines = MACHINES.length;
  const warnings = MACHINES.filter((m) => m.status !== "healthy").length;
  const avgHealth = Math.round(MACHINES.reduce((s, m) => s + m.health, 0) / MACHINES.length);

  return (
    <div className="space-y-8 p-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-2xl border border-border/60">
        <img src={heroImg} alt="Industrial control center" width={1536} height={420} className="absolute inset-0 h-full w-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-background/30" />
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative grid gap-6 p-8 md:grid-cols-[1fr_auto] md:items-end">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-[11px] uppercase tracking-wider text-primary">
              <span className="h-1.5 w-1.5 animate-pulse-glow rounded-full bg-primary" />
              Live • All sensors nominal
            </div>
            <h1 className="mt-4 font-display text-3xl font-bold leading-tight md:text-4xl">
              Enterprise AI <span className="text-gradient-primary">Predictive Maintenance</span> Platform
            </h1>
            <p className="mt-2 text-sm text-muted-foreground md:text-base">
              Smart industrial health monitoring using AI &amp; ML across your entire fleet.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild className="bg-gradient-to-r from-primary to-[oklch(0.85_0.18_200)] text-primary-foreground">
              <Link to="/industries">Browse industries <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/assistant"><Bot className="mr-1 h-4 w-4" />AI Assistant</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* KPIs */}
      <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Kpi icon={Cpu} label="Monitored Machines" value={String(totalMachines)} delta="across 4 industries" tone="primary" />
        <Kpi icon={Activity} label="Avg Health Score" value={`${avgHealth}%`} delta="last 24h trend ↑" tone="success" />
        <Kpi icon={AlertTriangle} label="Open Alerts" value={String(warnings)} delta="requires inspection" tone="warning" />
        <Kpi icon={Factory} label="Active Industries" value={String(INDUSTRIES.length)} delta="multi-site coverage" tone="accent" />
      </section>

      {/* Chart + alerts */}
      <section className="grid gap-4 lg:grid-cols-3">
        <Card className="border-border/60 bg-card/60 lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-base">Fleet Health (24h)</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent className="h-[280px] pl-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trend} margin={{ top: 10, right: 16, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="g1" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.74 0.13 195)" stopOpacity={0.55} />
                    <stop offset="100%" stopColor="oklch(0.74 0.13 195)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="t" tick={{ fill: "oklch(0.78 0.015 225)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "oklch(0.78 0.015 225)", fontSize: 11 }} axisLine={false} tickLine={false} domain={[60, 100]} />
                <Tooltip contentStyle={{ background: "oklch(0.27 0.025 235)", border: "1px solid oklch(0.42 0.025 235 / 60%)", borderRadius: 10, fontSize: 12 }} />
                <Area type="monotone" dataKey="health" stroke="oklch(0.74 0.13 195)" strokeWidth={2} fill="url(#g1)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/60">
          <CardHeader className="pb-2">
            <CardTitle className="font-display text-base">Alerts</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {MACHINES.filter((m) => m.status !== "healthy").map((m) => (
              <Link key={m.id} to="/machines/$machineId" params={{ machineId: m.id }} className="block rounded-lg border border-border/50 bg-background/60 p-3 transition hover:border-primary/40">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-sm font-medium">{m.name}</div>
                    <div className="text-xs text-muted-foreground">RUL {m.rulHours}h • {m.type}</div>
                  </div>
                  <StatusBadge status={m.status} />
                </div>
              </Link>
            ))}
            {MACHINES.every((m) => m.status === "healthy") && (
              <div className="text-sm text-muted-foreground">No active alerts.</div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Industry overview */}
      <section>
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="font-display text-xl font-bold">Industry overview</h2>
            <p className="text-sm text-muted-foreground">10 industries supported. Tap to drill down.</p>
          </div>
          <Button asChild variant="ghost" size="sm">
            <Link to="/industries">View all <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {INDUSTRIES.slice(0, 5).map((i) => (
            <Link key={i.id} to="/industries/$industryId" params={{ industryId: i.id }} className="group rounded-xl border border-border/60 bg-card/60 p-4 hover-lift hover-glow">
              <div className="flex items-center justify-between">
                <Factory className="h-4 w-4 text-muted-foreground transition group-hover:text-primary group-hover:scale-110" />
                <span className="text-[11px] uppercase tracking-wider text-muted-foreground">{i.machinesCount} machines</span>
              </div>
              <div className="mt-3 font-display text-base font-semibold transition group-hover:text-primary">{i.name}</div>
              <div className="mt-1 text-xs text-muted-foreground line-clamp-2">{i.description}</div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-secondary">
                <div className="h-full bg-gradient-to-r from-primary to-[oklch(0.82_0.13_190)] transition-all group-hover:brightness-125" style={{ width: `${i.health}%` }} />
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
