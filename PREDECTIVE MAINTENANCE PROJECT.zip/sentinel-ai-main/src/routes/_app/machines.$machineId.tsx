import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { StatusBadge } from "@/components/StatusBadge";
import { Gauge } from "@/components/Gauge";
import { AssistantChat } from "@/components/AssistantChat";
import { getMachine, getIndustry } from "@/lib/industries";
import { predictMachine, type PredictResult } from "@/server/predict.functions";
import { ArrowLeft, Loader2, Activity, ShieldAlert, Clock } from "lucide-react";
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export const Route = createFileRoute("/_app/machines/$machineId")({
  head: ({ params }) => {
    const m = getMachine(params.machineId);
    return {
      meta: [
        { title: `${m?.name ?? "Machine"} — PREDICT.AI` },
        { name: "description", content: m ? `${m.name}: ${m.usage}` : "Machine details and live prediction." },
      ],
    };
  },
  component: MachinePage,
});

const SENSOR_DEFS = [
  { key: "temperature", label: "Temperature", unit: "°C", min: 0, max: 120, step: 0.5, danger: [0, 95] as [number, number] },
  { key: "vibration", label: "Vibration", unit: "mm/s", min: 0, max: 10, step: 0.1, danger: [0, 6.5] as [number, number] },
  { key: "voltage", label: "Voltage", unit: "V", min: 150, max: 250, step: 1, danger: [185, 240] as [number, number] },
  { key: "current", label: "Current", unit: "A", min: 0, max: 10, step: 0.1, danger: [0, 8.5] as [number, number] },
  { key: "rpm", label: "RPM", unit: "rpm", min: 500, max: 3000, step: 10, danger: [500, 2700] as [number, number] },
  { key: "pressure", label: "Pressure", unit: "PSI", min: 0, max: 500, step: 1, danger: [0, 420] as [number, number] },
  { key: "oil_level", label: "Oil Level", unit: "%", min: 0, max: 100, step: 1, danger: [25, 100] as [number, number] },
  { key: "load_capacity", label: "Load Capacity", unit: "%", min: 0, max: 100, step: 1, danger: [0, 88] as [number, number] },
] as const;

type Sensors = Record<typeof SENSOR_DEFS[number]["key"], number>;
const DEFAULTS: Sensors = {
  temperature: 65, vibration: 3.2, voltage: 220, current: 4.5,
  rpm: 1800, pressure: 220, oil_level: 78, load_capacity: 65,
};

function MachinePage() {
  const { machineId } = Route.useParams();
  const machine = getMachine(machineId);
  if (!machine) throw notFound();
  const industry = getIndustry(machine.industryId);

  const [sensors, setSensors] = useState<Sensors>(DEFAULTS);
  const [result, setResult] = useState<PredictResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState<{ t: number; v: number; pred: number }[]>([]);
  const predict = useServerFn(predictMachine);

  // Debounced prediction with stale-result guard for smoother slider interaction
  useEffect(() => {
    let cancelled = false;
    const id = setTimeout(async () => {
      setBusy(true);
      try {
        const r = await predict({ data: { machineId, sensors } });
        if (cancelled) return;
        setResult(r);
        setHistory((h) => {
          const next = [...h, { t: Date.now(), v: sensors.vibration, pred: r.prediction }];
          return next.slice(-30);
        });
      } catch (e) {
        if (!cancelled) console.error(e);
      } finally {
        if (!cancelled) setBusy(false);
      }
    }, 250);
    return () => { cancelled = true; clearTimeout(id); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sensors]);

  const status: "healthy" | "warning" | "critical" = !result
    ? "healthy"
    : result.risk === "high" ? "critical" : result.risk === "medium" ? "warning" : "healthy";

  const rulPct = useMemo(() => Math.min(100, Math.round(((result?.rulHours ?? 0) / 2400) * 100)), [result]);

  return (
    <div className="space-y-6 p-6">
      <Button variant="ghost" size="sm" asChild>
        <Link to="/industries/$industryId" params={{ industryId: machine.industryId }}><ArrowLeft className="mr-1 h-4 w-4" />{industry?.name ?? "Industry"}</Link>
      </Button>

      {/* Header */}
      <Card className="overflow-hidden border-border/60 bg-card/60">
        <div className="grid gap-0 md:grid-cols-[280px_1fr]">
          <div className="relative h-48 md:h-auto">
            <img src={machine.image} alt={machine.name} loading="lazy" width={1024} height={768} className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-card" />
          </div>
          <div className="p-6">
            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge status={status} />
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground">{machine.type} • {industry?.name}</span>
            </div>
            <h1 className="mt-2 font-display text-2xl font-bold">{machine.name}</h1>
            <div className="mt-3 grid gap-2 text-sm md:grid-cols-2">
              <p><span className="text-muted-foreground">Industry usage:</span> {machine.usage}</p>
              <p><span className="text-muted-foreground">Why this machine:</span> {machine.reason}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Result + RUL */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-border/60 bg-card/60">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-muted-foreground">Prediction</span>
              {busy ? <Loader2 className="h-4 w-4 animate-spin text-primary" /> : <Activity className="h-4 w-4 text-primary" />}
            </div>
            <div className={`mt-2 font-display text-3xl font-bold ${result?.prediction === 1 ? "text-destructive" : "text-success"}`}>
              {result?.label ?? "—"}
            </div>
            <div className="text-xs text-muted-foreground">Confidence {result?.confidence ?? 0}% • {result?.source ?? "fallback"}</div>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/60">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-muted-foreground">Risk Level</span>
              <ShieldAlert className="h-4 w-4 text-warning" />
            </div>
            <div className="mt-2 font-display text-3xl font-bold uppercase">
              {result?.risk ?? "—"}
            </div>
            <div className="text-xs text-muted-foreground">Composite of all sensors</div>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/60">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-muted-foreground">Remaining Useful Life</span>
              <Clock className="h-4 w-4 text-primary" />
            </div>
            <div className="mt-2 font-display text-3xl font-bold">{result?.rulHours ?? "—"}<span className="ml-1 text-base text-muted-foreground">h</span></div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
              <div className="h-full bg-gradient-to-r from-success via-warning to-destructive" style={{ width: `${rulPct}%` }} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Model reasoning */}
      {result && (
        <Card className="border-border/60 bg-card/60 animate-in fade-in duration-300">
          <CardContent className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:justify-between">
            <div className="flex-1">
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Model reasoning</div>
              <p className="mt-1 text-sm">{result.summary}</p>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {result.contributions
                .filter((c) => c.status !== "normal")
                .sort((a, b) => b.weight - a.weight)
                .slice(0, 4)
                .map((c) => (
                  <span
                    key={c.key}
                    className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] ${
                      c.status === "critical"
                        ? "border-destructive/40 bg-destructive/10 text-destructive"
                        : "border-warning/40 bg-warning/10 text-warning"
                    }`}
                    title={c.note}
                  >
                    {c.label} {c.value}{c.unit}
                  </span>
                ))}
              {result.contributions.every((c) => c.status === "normal") && (
                <span className="inline-flex items-center gap-1 rounded-full border border-success/40 bg-success/10 px-2.5 py-1 text-[11px] text-success">
                  All sensors nominal
                </span>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Sliders */}
        <Card className="border-border/60 bg-card/60 lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="font-display text-base">Sensor Inputs</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {SENSOR_DEFS.map((d) => (
                <Gauge key={d.key} label={d.label} value={sensors[d.key]} min={d.min} max={d.max} unit={d.unit} danger={d.danger} />
              ))}
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {SENSOR_DEFS.map((d) => (
                <div key={d.key} className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs uppercase tracking-wider text-muted-foreground">{d.label}</Label>
                    <span className="text-xs tabular-nums">{sensors[d.key].toFixed(d.step < 1 ? 1 : 0)} {d.unit}</span>
                  </div>
                  <Slider
                    value={[sensors[d.key]]}
                    min={d.min}
                    max={d.max}
                    step={d.step}
                    onValueChange={(v) => setSensors((s) => ({ ...s, [d.key]: v[0] }))}
                  />
                </div>
              ))}
            </div>

            {history.length > 1 && (
              <div className="h-40 rounded-lg border border-border/60 bg-background/40 p-2">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history.map((p, i) => ({ i, v: p.v }))}>
                    <CartesianGrid stroke="oklch(1 0 0 / 6%)" vertical={false} />
                    <XAxis dataKey="i" tick={{ fill: "oklch(0.68 0.02 230)", fontSize: 10 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: "oklch(0.68 0.02 230)", fontSize: 10 }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ background: "oklch(0.20 0.03 240)", border: "1px solid oklch(0.30 0.03 235 / 70%)", borderRadius: 8, fontSize: 12 }} />
                    <Line type="monotone" dataKey="v" stroke="oklch(0.78 0.17 210)" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Network AI Chatbot for this machine */}
        <AssistantChat
          scope="machine"
          scopeId={machine.id}
          scopeLabel={machine.name}
          sensors={sensors}
        />
      </div>
    </div>
  );
}
