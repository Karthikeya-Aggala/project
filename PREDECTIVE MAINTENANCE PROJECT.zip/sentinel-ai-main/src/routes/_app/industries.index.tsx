import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { INDUSTRIES } from "@/lib/industries";
import { Factory, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_app/industries/")({
  head: () => ({
    meta: [
      { title: "Industries — PREDICT.AI" },
      { name: "description", content: "Browse 10 supported industries: oil & gas, manufacturing, power, mining, and more." },
    ],
  }),
  component: IndustriesPage,
});

function IndustriesPage() {
  return (
    <div className="space-y-6 p-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Industries</h1>
        <p className="text-sm text-muted-foreground">10 industries with dedicated monitoring, machine catalogs, and AI assistants.</p>
      </header>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {INDUSTRIES.map((i) => (
          <Link key={i.id} to="/industries/$industryId" params={{ industryId: i.id }} className="group">
            <Card className="h-full border-border/60 bg-card/60 hover-lift hover-glow group-hover:border-primary/50">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary transition group-hover:bg-primary/25 group-hover:scale-110">
                    <Factory className="h-4 w-4" />
                  </div>
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground">{i.machinesCount} machines</span>
                </div>
                <div className="mt-4 font-display text-lg font-semibold transition group-hover:text-primary">{i.name}</div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{i.tagline}</div>
                <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{i.description}</p>
                <div className="mt-4 flex items-center justify-between">
                  <div className="h-1.5 w-32 overflow-hidden rounded-full bg-secondary">
                    <div className="h-full bg-gradient-to-r from-primary to-[oklch(0.82_0.13_190)] transition-all duration-500 group-hover:brightness-125" style={{ width: `${i.health}%` }} />
                  </div>
                  <span className="text-xs text-muted-foreground">{i.health}% healthy</span>
                </div>
                <div className="mt-3 inline-flex items-center text-xs text-primary opacity-0 -translate-x-1 transition-all duration-200 group-hover:opacity-100 group-hover:translate-x-0">
                  Explore <ArrowRight className="ml-1 h-3 w-3" />
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
