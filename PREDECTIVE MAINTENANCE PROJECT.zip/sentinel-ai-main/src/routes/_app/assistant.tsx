import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AssistantChat } from "@/components/AssistantChat";
import { INDUSTRIES, MACHINES } from "@/lib/industries";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bot, Cpu, Factory } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/assistant")({
  head: () => ({
    meta: [
      { title: "AI Assistant — PREDICT.AI" },
      { name: "description", content: "Network-based AI assistants for every machine and every industry." },
    ],
  }),
  component: AssistantPage,
});

function AssistantPage() {
  const [scope, setScope] = useState<{ kind: "machine" | "industry"; id: string; label: string }>({
    kind: "machine", id: MACHINES[0].id, label: MACHINES[0].name,
  });

  return (
    <div className="space-y-6 p-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Network AI Assistants</h1>
        <p className="text-sm text-muted-foreground">Each machine and industry has its own AI specialist, served over the network.</p>
      </header>

      <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
        <Card className="border-border/60 bg-card/60">
          <CardHeader className="pb-2"><CardTitle className="font-display text-base">Choose an assistant</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">Industry</div>
              <div className="grid gap-1">
                {INDUSTRIES.map((i) => (
                  <Button
                    key={i.id}
                    variant="ghost"
                    size="sm"
                    onClick={() => setScope({ kind: "industry", id: i.id, label: i.name })}
                    className={cn("justify-start gap-2", scope.kind === "industry" && scope.id === i.id && "bg-primary/15 text-primary")}
                  >
                    <Factory className="h-4 w-4" /> {i.name}
                  </Button>
                ))}
              </div>
            </div>
            <div>
              <div className="mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">Machine</div>
              <div className="grid gap-1">
                {MACHINES.map((m) => (
                  <Button
                    key={m.id}
                    variant="ghost"
                    size="sm"
                    onClick={() => setScope({ kind: "machine", id: m.id, label: m.name })}
                    className={cn("justify-start gap-2", scope.kind === "machine" && scope.id === m.id && "bg-primary/15 text-primary")}
                  >
                    <Cpu className="h-4 w-4" /> {m.name}
                  </Button>
                ))}
              </div>
            </div>
            <div className="rounded-lg border border-border/60 bg-background/40 p-3 text-xs text-muted-foreground">
              <Bot className="mb-1 inline h-3.5 w-3.5 text-primary" /> Powered by Lovable AI Gateway. Configure <code className="text-foreground/80">ML_API_URL</code> to also connect your FastAPI random-forest service.
            </div>
          </CardContent>
        </Card>

        <AssistantChat
          key={`${scope.kind}-${scope.id}`}
          scope={scope.kind}
          scopeId={scope.id}
          scopeLabel={scope.label}
        />
      </div>
    </div>
  );
}
