import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { getIndustry, machinesByIndustry } from "@/lib/industries";
import { ArrowLeft, Bot, Cpu, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_app/industries/$industryId")({
  head: ({ params }) => {
    const i = getIndustry(params.industryId);
    return {
      meta: [
        { title: `${i?.name ?? "Industry"} — PREDICT.AI` },
        { name: "description", content: i?.description ?? "Industry overview and machine catalog." },
      ],
    };
  },
  component: IndustryPage,
});

function IndustryPage() {
  const { industryId } = Route.useParams();
  const industry = getIndustry(industryId);
  if (!industry) throw notFound();
  const machines = machinesByIndustry(industryId);

  return (
    <div className="space-y-8 p-6">
      <Button variant="ghost" size="sm" asChild>
        <Link to="/industries"><ArrowLeft className="mr-1 h-4 w-4" />All industries</Link>
      </Button>

      <header className="grid gap-4 md:grid-cols-[1fr_auto] md:items-end">
        <div>
          <div className="text-xs uppercase tracking-wider text-primary">{industry.tagline}</div>
          <h1 className="mt-1 font-display text-3xl font-bold">{industry.name}</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{industry.description}</p>
        </div>
        <Button asChild variant="outline">
          <Link to="/assistant"><Bot className="mr-1 h-4 w-4" />Industry AI Assistant</Link>
        </Button>
      </header>

      {/* Industry KPIs */}
      <div className="grid gap-3 sm:grid-cols-3">
        <Card className="border-border/60 bg-card/60"><CardContent className="p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Health</div>
          <div className="mt-1 font-display text-2xl font-bold">{industry.health}%</div>
        </CardContent></Card>
        <Card className="border-border/60 bg-card/60"><CardContent className="p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Machines</div>
          <div className="mt-1 font-display text-2xl font-bold">{industry.machinesCount}</div>
        </CardContent></Card>
        <Card className="border-border/60 bg-card/60"><CardContent className="p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Categories tracked</div>
          <div className="mt-1 font-display text-2xl font-bold">{Math.max(3, machines.length)}</div>
        </CardContent></Card>
      </div>

      <section>
        <h2 className="mb-3 font-display text-lg font-semibold">Machines in this industry</h2>
        {machines.length === 0 ? (
          <Card className="border-dashed border-border/60 bg-card/30">
            <CardContent className="p-8 text-center text-sm text-muted-foreground">
              Machine catalog for {industry.name} is being onboarded. Check back soon.
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {machines.map((m) => (
              <Link key={m.id} to="/machines/$machineId" params={{ machineId: m.id }} className="group">
                <Card className="overflow-hidden border-border/60 bg-card/60 hover-lift hover-glow group-hover:border-primary/50">
                  <div className="relative h-40 overflow-hidden">
                    <img src={m.image} alt={m.name} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-110" width={1024} height={768} />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                    <div className="absolute right-3 top-3"><StatusBadge status={m.status} /></div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Cpu className="h-4 w-4 text-primary transition group-hover:scale-110" />
                      <span className="font-display text-base font-semibold transition group-hover:text-primary">{m.name}</span>
                    </div>
                    <p className="mt-2 text-xs text-muted-foreground line-clamp-2"><span className="text-foreground/80">Use:</span> {m.usage}</p>
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-2"><span className="text-foreground/80">Why:</span> {m.reason}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">RUL {m.rulHours}h • {m.health}%</span>
                      <span className="inline-flex items-center text-xs text-primary opacity-70 transition group-hover:opacity-100 group-hover:translate-x-0.5">Open <ArrowRight className="ml-1 h-3 w-3" /></span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
