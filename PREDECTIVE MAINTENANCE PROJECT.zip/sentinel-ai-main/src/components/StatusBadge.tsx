import { cn } from "@/lib/utils";

type Status = "healthy" | "warning" | "critical";

const map: Record<Status, { label: string; cls: string; dot: string }> = {
  healthy: { label: "Healthy", cls: "bg-success/15 text-success border-success/30", dot: "bg-success" },
  warning: { label: "Warning", cls: "bg-warning/15 text-warning border-warning/30", dot: "bg-warning" },
  critical: { label: "Critical", cls: "bg-destructive/15 text-destructive border-destructive/30", dot: "bg-destructive" },
};

export function StatusBadge({ status, className }: { status: Status; className?: string }) {
  const m = map[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wider", m.cls, className)}>
      <span className={cn("h-1.5 w-1.5 rounded-full animate-pulse-glow", m.dot)} />
      {m.label}
    </span>
  );
}
