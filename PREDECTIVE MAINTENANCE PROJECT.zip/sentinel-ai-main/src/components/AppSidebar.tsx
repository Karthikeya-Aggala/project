import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, Factory, Cpu, BarChart3, Bot, Upload, LogOut, Activity } from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter, useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";

const items = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Industries", url: "/industries", icon: Factory },
  { title: "Machines", url: "/machines", icon: Cpu },
  { title: "Analytics", url: "/analytics", icon: BarChart3 },
  { title: "AI Assistant", url: "/assistant", icon: Bot },
  { title: "Bulk CSV", url: "/bulk", icon: Upload },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const path = useRouterState({ select: (r) => r.location.pathname });
  const { signOut, user, roles } = useAuth();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <Link to="/dashboard" className="flex items-center gap-2 px-2 py-3">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-primary to-[oklch(0.85_0.18_200)] shadow-glow">
            <Activity className="h-5 w-5 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="leading-tight">
              <div className="font-display text-sm font-bold tracking-wider">PREDICT.AI</div>
              <div className="text-[10px] text-muted-foreground">Industrial OS</div>
            </div>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Platform</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => {
                const active = path === item.url || path.startsWith(item.url + "/");
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={active} className="group/item interactive hover:bg-sidebar-accent hover:text-primary data-[active=true]:bg-primary/15 data-[active=true]:text-primary">
                      <Link to={item.url} className="flex items-center gap-3">
                        <item.icon className="h-4 w-4 transition group-hover/item:scale-110 group-hover/item:text-primary" />
                        {!collapsed && <span className="transition group-hover/item:translate-x-0.5">{item.title}</span>}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        {!collapsed && user && (
          <div className="px-2 py-2 text-xs">
            <div className="truncate font-medium">{user.email}</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {roles.length === 0 && <span className="text-muted-foreground">no role</span>}
              {roles.map((r) => (
                <span key={r} className="rounded-md bg-primary/15 px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-primary">
                  {r}
                </span>
              ))}
            </div>
          </div>
        )}
        <Button variant="ghost" size="sm" onClick={signOut} className="justify-start gap-2">
          <LogOut className="h-4 w-4" />
          {!collapsed && "Sign out"}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
