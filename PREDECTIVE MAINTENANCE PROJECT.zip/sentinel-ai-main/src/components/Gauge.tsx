import { cn } from "@/lib/utils";

export function Gauge({
  label, value, min, max, unit, danger,
}: { label: string; value: number; min: number; max: number; unit: string; danger?: [number, number] }) {
  const pct = Math.max(0, Math.min(1, (value - min) / (max - min)));
  const angle = -120 + pct * 240; // -120 to +120
  const inDanger = danger && (value < danger[0] || value > danger[1]);

  return (
    <div className="rounded-xl border border-border/60 bg-background/40 p-3">
      <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-muted-foreground">
        <span>{label}</span>
        <span className={cn(inDanger ? "text-destructive" : "text-primary")}>{value.toFixed(1)} {unit}</span>
      </div>
      <div className="relative mx-auto mt-2 h-16 w-32">
        <svg viewBox="0 0 120 70" className="h-full w-full">
          <defs>
            <linearGradient id={`gg-${label}`} x1="0" x2="1">
              <stop offset="0%" stopColor="oklch(0.78 0.17 210)" />
              <stop offset="60%" stopColor="oklch(0.80 0.17 75)" />
              <stop offset="100%" stopColor="oklch(0.65 0.24 25)" />
            </linearGradient>
          </defs>
          <path d="M10,60 A50,50 0 0,1 110,60" stroke="oklch(1 0 0 / 8%)" strokeWidth="8" fill="none" strokeLinecap="round" />
          <path
            d="M10,60 A50,50 0 0,1 110,60"
            stroke={`url(#gg-${label})`}
            strokeWidth="8"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={`${pct * 157} 157`}
          />
          <g transform={`rotate(${angle} 60 60)`}>
            <line x1="60" y1="60" x2="60" y2="22" stroke="oklch(0.96 0.01 220)" strokeWidth="2" strokeLinecap="round" />
            <circle cx="60" cy="60" r="3" fill="oklch(0.96 0.01 220)" />
          </g>
        </svg>
      </div>
    </div>
  );
}
