import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { chatWithAssistant } from "@/server/predict.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, Send, Loader2, User, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface Sensors {
  temperature: number; vibration: number; voltage: number; current: number;
  rpm: number; pressure: number; oil_level: number; load_capacity: number;
}

interface Msg { role: "user" | "assistant"; content: string }

const QUICK_PROMPTS_MACHINE = [
  "Diagnose current readings",
  "What should I do right now?",
  "Estimate remaining useful life",
];
const QUICK_PROMPTS_INDUSTRY = [
  "Top 3 failure modes",
  "Recommend a maintenance schedule",
  "Key KPIs to monitor",
];

export function AssistantChat({
  scope, scopeId, scopeLabel, sensors,
}: { scope: "machine" | "industry"; scopeId: string; scopeLabel: string; sensors?: Sensors }) {
  const chat = useServerFn(chatWithAssistant);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content: scope === "machine"
        ? `Hi — I am the dedicated AI engineer for **${scopeLabel}**. I see your live telemetry. Ask me to **diagnose**, **recommend actions**, or **estimate RUL**.`
        : `Hi — I am the **${scopeLabel}** industry advisor. Ask about reliability strategy, common failure modes, or maintenance KPIs.`,
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  useEffect(() => () => abortRef.current?.abort(), []);

  async function ask(text: string) {
    const trimmed = text.trim();
    if (!trimmed || busy) return;
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    const next: Msg[] = [...messages, { role: "user", content: trimmed }];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const res = await chat({
        data: {
          scope, scopeId, scopeLabel,
          history: next.map((m) => ({ role: m.role, content: m.content })),
          sensors,
        },
      });
      setMessages((cur) => [...cur, { role: "assistant", content: res.reply }]);
    } catch {
      setMessages((cur) => [...cur, { role: "assistant", content: "Network error. Please retry." }]);
    } finally {
      setBusy(false);
    }
  }

  const quick = scope === "machine" ? QUICK_PROMPTS_MACHINE : QUICK_PROMPTS_INDUSTRY;

  return (
    <Card className="flex h-[560px] flex-col border-border/60 bg-card/60">
      <CardHeader className="border-b border-border/60 pb-3">
        <CardTitle className="flex items-center gap-2 font-display text-base">
          <div className="grid h-7 w-7 place-items-center rounded-md bg-primary/15 text-primary"><Bot className="h-4 w-4" /></div>
          {scope === "machine" ? `${scopeLabel} Bot` : `${scopeLabel} Assistant`}
          <span className="ml-auto inline-flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-success" /> Network · Online
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col p-0">
        <div ref={scroller} className="flex-1 space-y-3 overflow-y-auto p-4">
          {messages.map((m, i) => (
            <div key={i} className={cn("flex gap-2 text-sm animate-in fade-in slide-in-from-bottom-1 duration-200", m.role === "user" ? "justify-end" : "justify-start")}>
              {m.role === "assistant" && (
                <div className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-primary/15 text-primary"><Bot className="h-3.5 w-3.5" /></div>
              )}
              <div className={cn(
                "max-w-[82%] rounded-2xl px-3 py-2 leading-relaxed",
                m.role === "user"
                  ? "bg-gradient-to-br from-primary to-[oklch(0.85_0.18_200)] text-primary-foreground"
                  : "border border-border/60 bg-background/60"
              )}>
                {m.role === "assistant" ? (
                  <div className="prose prose-sm prose-invert max-w-none prose-p:my-1.5 prose-ul:my-1.5 prose-ol:my-1.5 prose-li:my-0.5 prose-strong:text-foreground">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                  </div>
                ) : (
                  <span className="whitespace-pre-wrap">{m.content}</span>
                )}
              </div>
              {m.role === "user" && (
                <div className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-secondary"><User className="h-3.5 w-3.5" /></div>
              )}
            </div>
          ))}
          {busy && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <div className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-primary/15 text-primary"><Bot className="h-3.5 w-3.5" /></div>
              <div className="flex items-center gap-1 rounded-2xl border border-border/60 bg-background/60 px-3 py-2">
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary [animation-delay:-0.2s]" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary [animation-delay:-0.1s]" />
                <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary" />
              </div>
            </div>
          )}
        </div>

        {messages.length <= 1 && !busy && (
          <div className="flex flex-wrap gap-1.5 border-t border-border/60 px-3 pt-3">
            {quick.map((q) => (
              <button
                key={q}
                onClick={() => ask(q)}
                className="inline-flex items-center gap-1 rounded-full border border-border/60 bg-background/60 px-2.5 py-1 text-[11px] text-muted-foreground transition hover:border-primary/40 hover:text-foreground"
              >
                <Sparkles className="h-3 w-3" /> {q}
              </button>
            ))}
          </div>
        )}

        <form
          onSubmit={(e) => { e.preventDefault(); ask(input); }}
          className="flex items-center gap-2 border-t border-border/60 p-3"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about vibration, oil level, RUL, or actions…"
            disabled={busy}
            maxLength={1000}
            autoComplete="off"
          />
          <Button type="submit" disabled={busy || !input.trim()} size="icon" className="bg-gradient-to-br from-primary to-[oklch(0.85_0.18_200)] text-primary-foreground transition active:scale-95">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
