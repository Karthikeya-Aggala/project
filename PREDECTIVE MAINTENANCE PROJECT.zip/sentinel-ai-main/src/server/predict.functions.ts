import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SensorSchema = z.object({
  temperature: z.number().min(0).max(200),
  vibration: z.number().min(0).max(20),
  voltage: z.number().min(0).max(500),
  current: z.number().min(0).max(50),
  rpm: z.number().min(0).max(10000),
  pressure: z.number().min(0).max(2000),
  oil_level: z.number().min(0).max(100),
  load_capacity: z.number().min(0).max(100),
});
const PredictInput = z.object({
  machineId: z.string().min(1).max(100),
  sensors: SensorSchema,
});

export type SensorContribution = {
  key: string;
  label: string;
  value: number;
  unit: string;
  weight: number; // 0..1 contribution to risk
  status: "normal" | "watch" | "critical";
  note: string;
};

export type PredictResult = {
  prediction: 0 | 1;
  label: "Healthy" | "Failure";
  confidence: number;
  risk: "low" | "medium" | "high";
  rulHours: number;
  source: "ml-api" | "fallback";
  score: number; // 0..1
  contributions: SensorContribution[];
  summary: string;
  details?: string;
};

type Sensors = z.infer<typeof SensorSchema>;

// Per-sensor scoring with smooth ramps — closer to a calibrated Random Forest output
function scoreSensors(s: Sensors): SensorContribution[] {
  const ramp = (v: number, ok: number, bad: number) => {
    if (bad === ok) return 0;
    const x = (v - ok) / (bad - ok);
    return Math.max(0, Math.min(1, x));
  };
  const band = (v: number, low: number, high: number, soft: number) => {
    if (v >= low && v <= high) return 0;
    const dist = v < low ? low - v : v - high;
    return Math.max(0, Math.min(1, dist / soft));
  };

  const c: SensorContribution[] = [
    {
      key: "temperature", label: "Temperature", value: s.temperature, unit: "°C",
      weight: ramp(s.temperature, 75, 110),
      status: s.temperature > 100 ? "critical" : s.temperature > 85 ? "watch" : "normal",
      note: s.temperature > 100 ? "Severe overheating — bearing & winding risk" :
            s.temperature > 85 ? "Elevated thermal load" : "Within nominal envelope",
    },
    {
      key: "vibration", label: "Vibration", value: s.vibration, unit: "mm/s",
      weight: ramp(s.vibration, 4.5, 9),
      status: s.vibration > 7 ? "critical" : s.vibration > 5 ? "watch" : "normal",
      note: s.vibration > 7 ? "ISO 10816 zone D — imbalance/misalignment likely" :
            s.vibration > 5 ? "Zone C — schedule inspection" : "Zone A/B — acceptable",
    },
    {
      key: "voltage", label: "Voltage", value: s.voltage, unit: "V",
      weight: band(s.voltage, 200, 240, 40),
      status: s.voltage < 190 || s.voltage > 245 ? "critical" : (s.voltage < 200 || s.voltage > 240) ? "watch" : "normal",
      note: s.voltage < 200 ? "Under-voltage — torque loss & overheating" :
            s.voltage > 240 ? "Over-voltage — insulation stress" : "Stable supply",
    },
    {
      key: "current", label: "Current", value: s.current, unit: "A",
      weight: ramp(s.current, 7, 9.5),
      status: s.current > 9 ? "critical" : s.current > 7.5 ? "watch" : "normal",
      note: s.current > 9 ? "Near overload — check load & windings" :
            s.current > 7.5 ? "High draw — monitor" : "Normal draw",
    },
    {
      key: "rpm", label: "RPM", value: s.rpm, unit: "rpm",
      weight: ramp(s.rpm, 2400, 2900),
      status: s.rpm > 2800 ? "critical" : s.rpm > 2500 ? "watch" : "normal",
      note: s.rpm > 2800 ? "Overspeed — mechanical stress" :
            s.rpm > 2500 ? "Above rated band" : "Within rated band",
    },
    {
      key: "pressure", label: "Pressure", value: s.pressure, unit: "PSI",
      weight: ramp(s.pressure, 380, 470),
      status: s.pressure > 450 ? "critical" : s.pressure > 400 ? "watch" : "normal",
      note: s.pressure > 450 ? "Approaching relief setpoint" :
            s.pressure > 400 ? "Elevated — verify discharge" : "Stable",
    },
    {
      key: "oil_level", label: "Oil Level", value: s.oil_level, unit: "%",
      weight: ramp(40 - Math.min(s.oil_level, 40), 0, 25), // low oil = high risk
      status: s.oil_level < 25 ? "critical" : s.oil_level < 40 ? "watch" : "normal",
      note: s.oil_level < 25 ? "Critical lubrication — stop & top up" :
            s.oil_level < 40 ? "Low — refill soon" : "Adequate",
    },
    {
      key: "load_capacity", label: "Load Capacity", value: s.load_capacity, unit: "%",
      weight: ramp(s.load_capacity, 80, 100),
      status: s.load_capacity > 95 ? "critical" : s.load_capacity > 85 ? "watch" : "normal",
      note: s.load_capacity > 95 ? "Operating beyond design — derate" :
            s.load_capacity > 85 ? "Heavy load — limit duration" : "Sustainable",
    },
  ];
  return c;
}

function fallbackPredict(s: Sensors): PredictResult {
  const contributions = scoreSensors(s);
  // Weighted aggregation (vibration & temperature dominate, like real PdM models)
  const weights: Record<string, number> = {
    vibration: 1.6, temperature: 1.4, oil_level: 1.2, current: 1.1,
    load_capacity: 1.0, voltage: 0.9, pressure: 0.8, rpm: 0.7,
  };
  let num = 0, den = 0;
  for (const c of contributions) {
    const w = weights[c.key] ?? 1;
    num += c.weight * w;
    den += w;
  }
  // Non-linear amplification when multiple sensors are bad simultaneously
  const linear = num / den;
  const criticals = contributions.filter((c) => c.status === "critical").length;
  const score = Math.max(0, Math.min(1, linear + criticals * 0.08));

  const prediction: 0 | 1 = score >= 0.5 ? 1 : 0;
  const confidence = Math.round((prediction === 1 ? score : 1 - score) * 100);
  const rulHours = Math.max(8, Math.round(2400 * Math.pow(1 - score, 1.4)));
  const tier: "low" | "medium" | "high" = score < 0.33 ? "low" : score < 0.66 ? "medium" : "high";

  const top = [...contributions].sort((a, b) => b.weight - a.weight).slice(0, 2);
  const summary = prediction === 1
    ? `Failure likely within ~${rulHours}h. Primary drivers: ${top.map((t) => t.label.toLowerCase()).join(" and ")}.`
    : `Healthy operation. Closest watch points: ${top.map((t) => t.label.toLowerCase()).join(" and ")}.`;

  return {
    prediction,
    label: prediction === 1 ? "Failure" : "Healthy",
    confidence,
    risk: tier,
    rulHours,
    source: "fallback",
    score: Math.round(score * 100) / 100,
    contributions,
    summary,
  };
}

export const predictMachine = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => PredictInput.parse(data))
  .handler(async ({ data }): Promise<PredictResult> => {
    const apiBase = process.env.ML_API_URL;
    if (apiBase) {
      try {
        const res = await fetch(`${apiBase.replace(/\/$/, "")}/predict`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ machine_id: data.machineId, ...data.sensors }),
        });
        if (res.ok) {
          const j = (await res.json()) as Partial<PredictResult> & { prediction?: number; confidence?: number };
          const local = fallbackPredict(data.sensors);
          const prediction = (j.prediction === 1 ? 1 : 0) as 0 | 1;
          const confidence = typeof j.confidence === "number"
            ? Math.round(j.confidence * (j.confidence <= 1 ? 100 : 1))
            : local.confidence;
          return {
            ...local,
            prediction,
            label: prediction === 1 ? "Failure" : "Healthy",
            confidence,
            risk: j.risk ?? local.risk,
            rulHours: typeof j.rulHours === "number" ? j.rulHours : local.rulHours,
            source: "ml-api",
          };
        }
      } catch (e) {
        console.error("ML API call failed, using fallback:", e);
      }
    }
    return fallbackPredict(data.sensors);
  });

const ChatSchema = z.object({
  scope: z.enum(["machine", "industry"]),
  scopeId: z.string().min(1).max(100),
  scopeLabel: z.string().min(1).max(120),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant", "system"]),
        content: z.string().min(1).max(4000),
      })
    )
    .max(40),
  sensors: SensorSchema.optional(),
});

export const chatWithAssistant = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => ChatSchema.parse(d))
  .handler(async ({ data }) => {
    const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
    if (!LOVABLE_API_KEY) {
      return {
        reply:
          "AI Gateway is not configured yet. Once Lovable AI is enabled, this assistant will analyze your sensor data, identify abnormal conditions, and suggest preventive maintenance actions.",
        source: "stub" as const,
      };
    }

    // Compute live diagnosis so the AI grounds its answers in the same model the UI uses
    let diagnosis = "";
    if (data.sensors) {
      const r = fallbackPredict(data.sensors);
      const flagged = r.contributions
        .filter((c) => c.status !== "normal")
        .sort((a, b) => b.weight - a.weight)
        .map((c) => `  • ${c.label}: ${c.value}${c.unit} — ${c.status.toUpperCase()} (${c.note})`)
        .join("\n");
      diagnosis = `\n\nLive model assessment:\n- Status: ${r.label} (risk ${r.risk}, confidence ${r.confidence}%)\n- Estimated RUL: ${r.rulHours} hours\n- Risk score: ${r.score}\n${flagged ? `- Flagged sensors:\n${flagged}` : "- All sensors nominal."}`;
    }

    const sysContext =
      data.scope === "machine"
        ? `You are the dedicated PREDICT.AI maintenance engineer for the "${data.scopeLabel}". You are precise, calm, and practical.

Always:
- Ground every recommendation in the live sensor data and model assessment provided below.
- Reference specific readings (with units) when explaining a finding.
- Use short Markdown: bold key terms, bullet lists for actions, numbered steps for procedures.
- Prioritize actions: SAFETY first, then DIAGNOSE, then CORRECT, then MONITOR.
- If readings are normal, say so clearly and suggest preventive checks rather than inventing problems.
- Never fabricate sensor values. If asked about something not in the data, say it is not measured.
- Keep answers under 180 words unless the user asks for detail.`
        : `You are the PREDICT.AI industry advisor for the "${data.scopeLabel}" sector. Provide expert, concise guidance on equipment reliability, common failure modes, and best-practice maintenance strategy. Use Markdown bullets. Keep replies under 180 words unless asked.`;

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: sysContext + diagnosis },
            ...data.history,
          ],
        }),
      });
      if (!res.ok) {
        const t = await res.text();
        return { reply: `Assistant temporarily unavailable (${res.status}).`, source: "error" as const, details: t.slice(0, 200) };
      }
      const j = await res.json();
      const reply: string = j.choices?.[0]?.message?.content ?? "(no response)";
      return { reply, source: "ai" as const };
    } catch (e) {
      return { reply: "Assistant is offline. Please try again.", source: "error" as const, details: String(e).slice(0, 200) };
    }
  });
