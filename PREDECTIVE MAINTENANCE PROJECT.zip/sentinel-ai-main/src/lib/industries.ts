export interface Industry {
  id: string;
  name: string;
  tagline: string;
  description: string;
  color: string; // tailwind/oklch hint via css var name
  machinesCount: number;
  health: number;
}

export const INDUSTRIES: Industry[] = [
  { id: "oil-gas", name: "Oil & Gas", tagline: "Upstream • Midstream • Downstream", description: "Drilling rigs, compressors, and pipeline assets.", color: "primary", machinesCount: 24, health: 92 },
  { id: "petroleum-refinery", name: "Petroleum Refinery", tagline: "Distillation & Cracking", description: "Refinery columns, heat exchangers, catalytic units.", color: "accent", machinesCount: 18, health: 88 },
  { id: "manufacturing", name: "Manufacturing", tagline: "Discrete & Process", description: "CNC, robotics, conveyor and packaging lines.", color: "primary", machinesCount: 42, health: 95 },
  { id: "power-generation", name: "Power Generation", tagline: "Thermal • Hydro • Renewable", description: "Turbines, generators, transformers.", color: "accent", machinesCount: 16, health: 90 },
  { id: "mining", name: "Mining", tagline: "Surface & Underground", description: "Crushers, draglines, conveyors, haul trucks.", color: "primary", machinesCount: 21, health: 81 },
  { id: "chemical", name: "Chemical", tagline: "Reactors & Process", description: "Reactors, mixers, separators.", color: "accent", machinesCount: 19, health: 87 },
  { id: "automotive", name: "Automotive", tagline: "Assembly & Stamping", description: "Stamping presses, welding robots, paint lines.", color: "primary", machinesCount: 33, health: 93 },
  { id: "food-processing", name: "Food Processing", tagline: "Hygienic Production", description: "Mixers, ovens, packaging, refrigeration.", color: "accent", machinesCount: 27, health: 96 },
  { id: "steel-metal", name: "Steel & Metal", tagline: "Hot & Cold Rolling", description: "Furnaces, rolling mills, casters.", color: "primary", machinesCount: 14, health: 78 },
  { id: "water-treatment", name: "Water Treatment", tagline: "Municipal & Industrial", description: "Pumps, aerators, filtration, UV systems.", color: "accent", machinesCount: 22, health: 94 },
];

export interface Machine {
  id: string;
  name: string;
  type: string;
  industryId: string;
  image: string;
  usage: string;
  reason: string;
  health: number;
  rulHours: number;
  status: "healthy" | "warning" | "critical";
}

import cnc from "@/assets/machine-cnc.jpg";
import turbine from "@/assets/machine-turbine.jpg";
import pump from "@/assets/machine-pump.jpg";

export const MACHINES: Machine[] = [
  {
    id: "cnc-01",
    name: "CNC Milling Machine",
    type: "CNC",
    industryId: "manufacturing",
    image: cnc,
    usage: "Precision machining of metal and composite parts in discrete manufacturing lines.",
    reason: "Critical for tight-tolerance components — failure halts upstream and downstream production.",
    health: 92,
    rulHours: 1820,
    status: "healthy",
  },
  {
    id: "turbine-01",
    name: "Gas Turbine",
    type: "Turbine",
    industryId: "oil-gas",
    image: turbine,
    usage: "Drives compressors and generators on offshore platforms and refineries.",
    reason: "High-value asset where unplanned downtime costs millions per day.",
    health: 87,
    rulHours: 4320,
    status: "healthy",
  },
  {
    id: "pump-01",
    name: "Centrifugal Pump",
    type: "Pump",
    industryId: "oil-gas",
    image: pump,
    usage: "Moves crude, refined product, and process fluids across the plant.",
    reason: "Bearing wear and cavitation are leading causes of unplanned shutdowns.",
    health: 74,
    rulHours: 920,
    status: "warning",
  },
  {
    id: "compressor-01",
    name: "Reciprocating Compressor",
    type: "Compressor",
    industryId: "oil-gas",
    image: pump,
    usage: "Boosts gas pressure for transport and reinjection.",
    reason: "Valve failure and rod packing wear are dominant failure modes.",
    health: 81,
    rulHours: 1540,
    status: "healthy",
  },
  {
    id: "mill-01",
    name: "CNC Lathe",
    type: "CNC",
    industryId: "manufacturing",
    image: cnc,
    usage: "Turns cylindrical parts to micron-level tolerance for assembly lines.",
    reason: "Spindle bearing degradation drives surface-finish defects and rework.",
    health: 88,
    rulHours: 2100,
    status: "healthy",
  },
  {
    id: "turbine-02",
    name: "Steam Turbine",
    type: "Turbine",
    industryId: "power-generation",
    image: turbine,
    usage: "Converts thermal energy from steam into rotating mechanical power for generators.",
    reason: "Blade fatigue and seal wear are dominant failure modes at base-load plants.",
    health: 90,
    rulHours: 3600,
    status: "healthy",
  },
  {
    id: "pump-02",
    name: "Booster Pump",
    type: "Pump",
    industryId: "water-treatment",
    image: pump,
    usage: "Maintains distribution pressure across municipal water networks.",
    reason: "Seal failure causes leakage and energy loss; impeller cavitation reduces output.",
    health: 84,
    rulHours: 1280,
    status: "healthy",
  },
];

export function machinesByIndustry(industryId: string) {
  return MACHINES.filter((m) => m.industryId === industryId);
}
export function getMachine(id: string) {
  return MACHINES.find((m) => m.id === id);
}
export function getIndustry(id: string) {
  return INDUSTRIES.find((i) => i.id === id);
}
